# UBIT shiyan 
# UBIT weibinma
from urllib.request import urlopen
from bs4 import BeautifulSoup
import re
import time
from socket import timeout
import requests


def get_url_list(url):
    try:
        url_list = []
        page = urlopen(url)
        soup = BeautifulSoup(page, 'html.parser')
        story_link = soup.find_all('a', class_="story-link")
        for links in story_link:
            link = links.get('href')
            url_list.append(link)
        if len(url_list) != 0:
            return url_list
    except:
        print('error')


def alphabet(raw_str):
    alphab = raw_str.encode().decode('ascii', 'ignore')
    return alphab


def write_txt(response, txt_name_prefix):
    soup = BeautifulSoup(response, 'html.parser')
    article_title = alphabet(soup.title.text.split(' - ')[0])
    split_title = article_title.split(' ')
    if len(split_title) < 3:
        name = alphabet(split_title[0]) + '_' + alphabet(split_title[1])
    else:
        name = alphabet(split_title[0]) + '_' + alphabet(split_title[1]) + '_' + alphabet(split_title[2])
    # get txt file name
    txt_name = txt_name_prefix + name + '.txt'
    # print(txt_name)
    try:
        nytimes_article = open(txt_name, 'a+')
        nytimes_article.write(article_title)
        # print('title', article_title)
        contents = soup.find_all('p', attrs={'class': 'story-body-text story-content'})
        for text_content in contents:
            article_text = alphabet(text_content.text)
            nytimes_article.write(article_text)
        nytimes_article.close()
    except IOError:
        print('open txt failed')

def write_article_to_txt(url_list):
    if url_list is None:
        return 'nonetype'
    for i in range(len(url_list)):
        try:
            url_link = url_list[i]
            response = urlopen(url_link)
            sports = '/sports/'
            politics = '/politics/'
            business = '/business/'
            travel = '/travel/'
            food = '/dining/'
            nytimes = 'www.nytimes.com/2'
            # print(url_link)
            if response.status == 200:
                print('jjjjjjjj  ',i)
                # print(url_link)
                if url_link.find(nytimes) != -1:
                    # print('hhhhh')
                    if url_link.find(politics) != -1:
                        print(i)
                        write_txt(response, 'politics_')
                    # elif url_link.find(sports) != -1:
                    #     write_txt(response, 'sports_')
                    # elif url_link.find(business) != -1:
                    #     write_txt(response, 'business_')
                    # elif url_link.find(food) != -1:
                    #     write_txt(response, 'food_')
                    else:
                        continue
        except:
            continue


def filter_utl(url_list, key):
    filtered_url_list = []
    for i in range(len(url_list)):
        re = url_list[i].find(key)
        if re != -1:
            # print(url_list[i])
            filtered_url_list.append(url_list[i])
    return filtered_url_list


def final_step(url_list):
    for i in range(len(url_list)):
        link_list_1 = get_url_list(url_list[i])
        if link_list_1 == 'error':
            continue
        elif link_list_1 != 'error':
            if write_article_to_txt(link_list_1) == 'nonetype':
                continue


sports_url = ['https://www.nytimes.com/section/sports',
              'https://www.nytimes.com/section/sports/baseball',
              'https://www.nytimes.com/section/sports/football',
              'https://www.nytimes.com/section/sports/ncaafootball',
              'https://www.nytimes.com/section/sports/basketball',
              'https://www.nytimes.com/section/sports/ncaabasketball',
              'https://www.nytimes.com/section/sports/hockey',
              'https://www.nytimes.com/section/sports/soccer',
              'https://www.nytimes.com/section/sports/tennis', ]

politics_url = ["https://www.nytimes.com/section/politics",
                'https://www.nytimes.com/section/us',
                'https://www.nytimes.com/section/upshot',
                '']

business_url = ['https://www.nytimes.com/section/business',
                'https://www.nytimes.com/section/business/dealbook',
                'https://www.nytimes.com/section/business/economy',
                'https://www.nytimes.com/section/business/smallbusiness']

food_url = ['https://www.nytimes.com/section/food',
            'https://www.nytimes.com/section/food/drinks',
            'https://www.nytimes.com/reviews/dining']

ny = ['https://cn.nytimes.com/']

all_urls_list =  sports_url + politics_url + business_url + ny +food_url
test = ['https://www.nytimes.com/section/politics']
final_step(all_urls_list)
